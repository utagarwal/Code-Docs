sap.ui.define([
	"sap/ui/core/mvc/Controller",
		'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel',
	'sap/m/Token',
	'sap/ui/model/FilterOperator'
], function (Controller, Filter, JSONModel, Token, FilterOperator) {
	"use strict";

	return Controller.extend("test.MultiInputApp.controller.View1", {
		onInit: function () {
this.testfrag = sap.ui.xmlfragment("test.MultiInputApp.view.testfrag",this.getView().getController());
//this.taskf4 = sap.ui.xmlfragment("test.MultiInputApp.view.taskf4",this.getView().getController());

			var cutoverData = [{
				SeqNo: "1",
				Task: "BP Screen fields overlap",
				Team: "Development",
				Action: "More Details",
				Duration: "10 min"
			}, {
				SeqNo: "2",
				Task: "ICM RULESET index table generation",
				Team: "Development",
				Action: "More Details",
				Duration: "15 min"
			}];
			var CutoverTableModel = new sap.ui.model.json.JSONModel(cutoverData);
			this.getView().setModel(CutoverTableModel, "CutoverTableModel");
			
				var spddData = [{
				Item: "Notes",
				Count: "10/20"
			}, {
				Item: "With Assistant",
				Count: "28/42"
			}, {
				Item: "Without Assistant",
				Count: "0/70"
			}, {
				Item: "Deletions",
				Count: "2"
			}];
			var oModel1 = new sap.ui.model.json.JSONModel(spddData);
			this.getView().setModel(oModel1, "MainModel");
			
		
this.getView().addDependent(this.testfrag);
		},
		
		
		click: function(){
				this.getView().addDependent(this.testfrag);
				this.testfrag.open();
				var token = new sap.m.Token({
					key: "Notes",
					text: "Notes",
					selected: true
				});
				
				sap.ui.getCore().byId("multiInput").addToken(new Token({
						text: "Notes"
					}));
		//	sap.ui.getCore().byId("multiInput").insertToken(token);
			sap.ui.getCore().byId("multiInput").updateInputField();
			sap.ui.getCore().byId("multiInput").fireTokenUpdate();
		},
		
		
			handleValueHelp: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			 if(!this.taskf4){
			this.taskf4 = sap.ui.xmlfragment("test.MultiInputApp.view.taskf4",this.getView().getController());
				this.getView().addDependent(this.taskf4);
			 }
				this.taskf4.open();
					var aTokens = sap.ui.getCore().byId("multiInput").getTokens();
			var aItems = this.taskf4.getItems();
			for (var j in aItems){
				for( var k in aTokens ) {
					if( aItems[j].getTitle() === aTokens[k].getText() ) {
						aItems[j].setSelected(true);
					}
				}
			}
		},

		_openValueHelpDialog: function (sInputValue) {
			// create a filter for the binding
			this.taskf4.getBinding("items").filter([new Filter(
				"Item",
				FilterOperator.Contains,
				sInputValue
			)]);

			// open value help dialog filtered by the input value
			this.taskf4.open(sInputValue);
		},

		_handleValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Item",
				FilterOperator.Contains,
				sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClose: function (evt) {
			var aSelectedItems = evt.getParameter("selectedItems"),
				oMultiInput = sap.ui.getCore().byId("multiInput");

			if (aSelectedItems && aSelectedItems.length > 0) {
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			}
			else{
				oMultiInput.removeAllTokens();
			}
		}
		
		
		
	});
});