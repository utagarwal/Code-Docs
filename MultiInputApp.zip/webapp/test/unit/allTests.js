sap.ui.define([
	"test/MultiInputApp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});