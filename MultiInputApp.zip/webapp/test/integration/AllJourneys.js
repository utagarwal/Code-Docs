/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"test/MultiInputApp/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"test/MultiInputApp/test/integration/pages/View1",
	"test/MultiInputApp/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "test.MultiInputApp.view.",
		autoWait: true
	});
});